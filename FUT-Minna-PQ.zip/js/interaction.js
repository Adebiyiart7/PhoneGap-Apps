//...........................................................
//CONSISTENT HEADER AND FOOTER
//...........................................................
$(document).ready(function() {
    $( "[data-role = 'header'], [data-role=footer]" ).toolbar();
});

//...........................................................
// ####### TOP NAV DRPDOWN #######
//...........................................................
function dropdownClick() {
    var x = document.getElementById("dropdownClick");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
  }

//...........................................................  
// ####### Sticky Nav Bar #######
//...........................................................
//   window.onscroll = function() {myFunction()
//   var nav = document.getElementById("nav");
//   var sticky = navbar.offsetTo
//   function myFunction() {
//   if (window.pageYOffset >= sticky) {
//   nav.classList.add("sticky")
//   } else {
//    nav.classList.remove("sticky");
//   }
// }