//....................................................................................
//  QUIZ ALGORITHM
//....................................................................................
function submitAnswers() {
    var total = 40;
    var score = 0;
    //USER INPUT
    var q1 = document.forms["quizForm"]["q1"].value;
    var q2 = document.forms["quizForm"]["q2"].value;
    var q3 = document.forms["quizForm"]["q3"].value;
    var q4 = document.forms["quizForm"]["q4"].value;
    var q5 = document.forms["quizForm"]["q5"].value;
    var q6 = document.forms["quizForm"]["q6"].value;
    var q7 = document.forms["quizForm"]["q7"].value;
    var q8 = document.forms["quizForm"]["q8"].value;
    var q9 = document.forms["quizForm"]["q9"].value;
    var q10 = document.forms["quizForm"]["q10"].value;
    var q11 = document.forms["quizForm"]["q11"].value;
    var q12 = document.forms["quizForm"]["q12"].value;
    var q13 = document.forms["quizForm"]["q13"].value;
    var q14 = document.forms["quizForm"]["q14"].value;
    var q15 = document.forms["quizForm"]["q15"].value;
    var q16 = document.forms["quizForm"]["q16"].value;
    var q17 = document.forms["quizForm"]["q17"].value;
    var q18 = document.forms["quizForm"]["q18"].value;
    var q19 = document.forms["quizForm"]["q19"].value;
    var q20 = document.forms["quizForm"]["q20"].value;
    var q21 = document.forms["quizForm"]["q21"].value;
    var q22 = document.forms["quizForm"]["q22"].value;
    var q23 = document.forms["quizForm"]["q23"].value;
    var q24 = document.forms["quizForm"]["q24"].value;
    var q25 = document.forms["quizForm"]["q25"].value;
    var q26 = document.forms["quizForm"]["q26"].value;
    var q27 = document.forms["quizForm"]["q27"].value;
    var q28 = document.forms["quizForm"]["q28"].value;
    var q29 = document.forms["quizForm"]["q29"].value;
    var q30 = document.forms["quizForm"]["q30"].value;
    var q31 = document.forms["quizForm"]["q31"].value;
    var q32 = document.forms["quizForm"]["q32"].value;
    var q33 = document.forms["quizForm"]["q33"].value;
    var q34 = document.forms["quizForm"]["q34"].value;
    var q35 = document.forms["quizForm"]["q35"].value;
    var q36 = document.forms["quizForm"]["q36"].value;
    var q37 = document.forms["quizForm"]["q37"].value;
    var q38 = document.forms["quizForm"]["q38"].value;
    var q39 = document.forms["quizForm"]["q39"].value;
    var q40 = document.forms["quizForm"]["q40"].value;
//....................................................................................
    //CORRECT ANSWERS
//....................................................................................

    var answers = ["d", "a", "c", "d", "d", "d", "b", "d", "c", "d",
                   "d", "c", "c", "a", "d", "a", "b", "d", "b", "c",
                   "a", "b", "b", "d", "d", "b", "d", "d", "c", "c",
                   "d", "c", "a", "c", "d", "c", "c", "a", "c", "d"
                    ];

//....................................................................................
    //CHECK ANSWERS
//....................................................................................
    for(i = 1; i <= total; i++){
        if(eval("q" + i) === answers [i - 1]){
        score++;
        }
    }
 //....................................................................................
    //DISPLAY RESULT
 //....................................................................................
    var results = document.getElementById("results");
    results.innerHTML = "<h3>You scored " + score * 10 + " <span>out of " + total * 10;
    return false;
}   
//........................................................................................